package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


class CalculatorTest {

    private Calculator calculator;

    // This method runs before EVERY individual test method execution
    @BeforeEach
    void setUp() {
        calculator = new Calculator();
    }

    @Test
    void testAdd() {
        int result = calculator.add(5, 3);
        // Assert that the expected value (8) matches the actual result
        assertEquals(8, result, "5 + 3 should equal 8");
    }

    @Test
    void testSubtract() {
        int result = calculator.subtract(10, 4);
        assertEquals(6, result, "10 - 4 should equal 6");
    }

    @Test
    void testDivide() {
        double result = calculator.divide(10, 2);
        assertEquals(5.0, result, "10 / 2 should equal 5.0");
    }

    @Test
    void testDivideByZeroThrowsException() {
        // Assert that an IllegalArgumentException is thrown when dividing by zero
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            calculator.divide(10, 0);
        });

        // Optional: Verify the exact exception message
        assertEquals("Cannot divide by zero!", exception.getMessage());
    }

    @Disabled("Skipping this test intentionally to demonstrate @Disabled annotation")
    @Test
    void testSkippedFeature() {
        fail("This test will fail, but it's disabled so it won't affect the build.");
    }
}